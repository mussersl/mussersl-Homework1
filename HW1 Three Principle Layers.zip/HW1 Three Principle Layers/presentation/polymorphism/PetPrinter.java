package polymorphism;

public class PetPrinter implements Printer {

	@Override
	public void printMessage(String msg) {
		System.out.println(msg);
	}

}
