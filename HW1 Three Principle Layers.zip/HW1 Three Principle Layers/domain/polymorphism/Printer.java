package polymorphism;

public interface Printer {
	public void printMessage(String msg);
}
