package polymorphism;

public class Cat extends Pet {

	public Cat(String name) {
		super(name);
	}

	@Override
	public void doSpecialAbility() {
		String msg = getName() + " says: Yawn. Zzz...";
		PetLogger log = new PetLogger();
		log.logMessage(msg);
	}
}
