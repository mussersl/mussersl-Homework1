package polymorphism;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class PetLogger {
	public void logMessage(String msg) {
		try(PrintStream stream = new PrintStream(new FileOutputStream("petLog.txt", true))) {
			stream.println(msg);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
