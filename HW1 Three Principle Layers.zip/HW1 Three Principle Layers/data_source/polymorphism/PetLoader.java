package polymorphism;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.function.Supplier;

public class PetLoader {
	public List<Pet> loadPets() {
		List<Pet> pets = null;

		try(Scanner in = new Scanner(new FileInputStream("pets.txt"))){
			pets = loadPetsFromFile(in);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Error loading pets", e);
		}
		return pets;
	}
	
	HashMap<String, Supplier<Pet>> petConstructionMap = new HashMap<>();

	
	public void addPetSupplier(String petType, Supplier<Pet> petSource) {
		petConstructionMap.put(petType, petSource);
	}

	private List<Pet> loadPetsFromFile(Scanner in) {
		List<Pet> pets = new ArrayList<Pet>();
		
		// Supplier is a Strategy for producing Pets.
		// Sometimes you will see a Map of Strategies, like this.
		// TODO: create an addPetSupplier(...) and watch what happens!
		
		// Strategies may have many implementations, like these three lambdas here
		petConstructionMap.put("Cat", () -> new Cat(in.next()));
		petConstructionMap.put("Dog", () -> {
			String dogName = in.next();
			boolean isGoodBoy = "good".equals(in.next());
			return new Dog(dogName, isGoodBoy); // FIXME: see UML	
		});
		petConstructionMap.put("Fish", () -> new Fish(in.next(), in.nextInt()));
		
		while(in.hasNext()) {
			String petType = in.next();
			// Getting the Strategy from the Map by its name
			Supplier<Pet> petReader = petConstructionMap.get(petType);
			
			// Invoking the Strategy - we do not know which implementation it is!
			Pet constructedPet = petReader.get();
			pets.add(constructedPet);
		}
		return pets;
	}
}
