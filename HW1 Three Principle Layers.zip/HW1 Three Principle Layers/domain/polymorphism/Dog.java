package polymorphism;

public class Dog extends Pet {
	
	public boolean isGoodDog = true;
	
	public Dog(String name, boolean isGoodDog) {
		super(name);
		this.isGoodDog = isGoodDog;
	}

	@Override
	public void doSpecialAbility() {
		String msg = getName() + " says: ";
		if (startsWithVowel(this.getName())) {
			msg += ("Arf!\n");
		} else {
			msg += ("Bow wow!\n");
		}
		msg += (isGoodDog ? "Good dog!" : "Bad dog!");
		PetLogger log = new PetLogger();
		log.logMessage(msg);
		
	}
	
	private boolean startsWithVowel(String s) {
		char ch = Character.toLowerCase(s.charAt(0));
		// When y is the first letter of a word, it isn't a vowel.
		return ch == 'a' || ch == 'e' || ch == 'i' 
				|| ch == 'o' || ch == 'u';
	}	
}
