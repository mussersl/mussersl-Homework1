package polymorphism;

public class Fish extends Pet {
	private int numWiggles;

	public Fish(String name, int numWiggles) {
		super(name);
		this.numWiggles = numWiggles;
	}
	
	@Override
	public void doSpecialAbility() {
		String msg = getName() + " says, time to move!\n";
		for (int j = 1; j <= this.numWiggles; j++) {
			msg += "Wiggle " + j + "\n";
		}
		msg = msg.substring(0,msg.length()-1);
		PetLogger log = new PetLogger();
		log.logMessage(msg);
	}
}
